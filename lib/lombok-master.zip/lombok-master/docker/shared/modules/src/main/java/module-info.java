module foo {
	requires static lombok;
}