package java.nio.file;

public class Path {
}
