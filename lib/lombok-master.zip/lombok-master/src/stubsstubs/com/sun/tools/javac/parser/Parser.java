package com.sun.tools.javac.parser;

public class Parser {
	public static class Factory {}
}
